#include <iostream>
#include <list>
using namespace std;
class Personne {
public :
string nom;
string prenom;
int age ;
public :
Personne(){
    cout<<"entrez votre nom ";
    cin>>nom;
    cout<<"entrez votre prenom ";
    cin>>prenom;
    cout<<"entrez votre age ";
    cin>>age;
}
};
int main()
{
list<Personne> list1;
list1.push_back(Personne());
list <Personne> list2;
list2.push_back(Personne());
std::list<Personne>::iterator it;
for (it = list1.begin(); it != list1.end(); ++it){
std::cout << it->nom<<" ";
std::cout << it->prenom<<" ";
std::cout << it->age<<" ";
cout<<"\n";
}
std::list<Personne>::iterator i;

for (i = list2.begin(); i != list2.end(); ++i){
std::cout << i->nom<<" ";
std::cout << i->prenom<<" ";
std::cout << i->age<<" ";
cout<<"\n";
}
return 0;
}






