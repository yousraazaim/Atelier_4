#include <iostream>
#include <list>
using namespace std;
int main()
{
	int x ,n;
list <int> liste;
cout<<"entrez le nombre des entiers :  " ;
cin>>n;
cout << endl;
for (int i = 0; i < n; ++i)
{
cout<<"donnez la valeur des entires: " ;
	 cin>>x;	
	 liste.push_back(x);
}
cout<<endl;
liste.sort();
cout<<"la liste triee est :  ";
list <int> :: iterator it;
for(it = liste.begin(); it != liste.end(); ++it)
cout << '\t' << *it;

return 0;
}


